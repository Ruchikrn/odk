export const color = {
    color_1: "#00b150",
    color_2: "#ffc100",
    color_3: "#ff0000",
    color_4: "#f5b183",
    color_5: "#add8e6"
}