export const host = "https://backend-ceonc.herokuapp.com"
// export const host = "http://localhost:4000"